$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/main/resources/feature/Taskmanagemen.Feature");
formatter.feature({
  "line": 2,
  "name": "Task_Management Website",
  "description": "",
  "id": "task-management-website",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Task_Management"
    }
  ]
});
formatter.scenario({
  "line": 5,
  "name": "Add/Edit Task in TaskMangement Website",
  "description": "",
  "id": "task-management-website;add/edit-task-in-taskmangement-website",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 4,
      "name": "@TC_01_Edit"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "The user launch the Chrome application",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "Click first task from the tasks list",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "Edit name field from Add/Edit task",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "Click on submit Button to update task",
  "keyword": "And "
});
formatter.match({
  "location": "EditTaskStep.the_user_launch_chrome_edit()"
});
formatter.result({
  "duration": 13755070100,
  "status": "passed"
});
formatter.match({
  "location": "EditTaskStep.click_any_task_from_the_Tasks_list()"
});
formatter.result({
  "duration": 3686163200,
  "status": "passed"
});
formatter.match({
  "location": "EditTaskStep.edit_any_one_field_from_Add_Edit_task()"
});
formatter.result({
  "duration": 185356400,
  "status": "passed"
});
formatter.match({
  "location": "EditTaskStep.click_on_submit_Button()"
});
formatter.result({
  "duration": 8475282501,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "Deleting a Task in TaskMangement Website",
  "description": "",
  "id": "task-management-website;deleting-a-task-in-taskmangement-website",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 11,
      "name": "@TC_02_Delete"
    }
  ]
});
formatter.step({
  "line": 13,
  "name": "user launch the Chrome application",
  "keyword": "Given "
});
formatter.step({
  "line": 14,
  "name": "Click first task from tasks list",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "Click delete button to delete the task",
  "keyword": "Then "
});
formatter.match({
  "location": "DeleteTaskStep.the_user_launch_chrome_de()"
});
formatter.result({
  "duration": 13417293599,
  "status": "passed"
});
formatter.match({
  "location": "DeleteTaskStep.click_any_task_from_tasks_list()"
});
formatter.result({
  "duration": 5883841200,
  "status": "passed"
});
formatter.match({
  "location": "DeleteTaskStep.click_delete_button_to_delete_details()"
});
formatter.result({
  "duration": 4174444200,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Checking Deleted details is show are not in TaskMangement Website",
  "description": "",
  "id": "task-management-website;checking-deleted-details-is-show-are-not-in-taskmangement-website",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 17,
      "name": "@TC_03_Searching_Delete_Task"
    }
  ]
});
formatter.step({
  "line": 19,
  "name": "The user launch Chrome application",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "Fill the deleted task details in Search box",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "Click the search button",
  "keyword": "Then "
});
formatter.step({
  "line": 22,
  "name": "Print the search result in the console",
  "keyword": "And "
});
formatter.match({
  "location": "SearchDeleteStep.the_user_launch_chrome_sd()"
});
formatter.result({
  "duration": 11290822900,
  "status": "passed"
});
formatter.match({
  "location": "SearchDeleteStep.fill_the_deleted_details_in_Search_box()"
});
formatter.result({
  "duration": 268396899,
  "status": "passed"
});
formatter.match({
  "location": "SearchDeleteStep.click_the_search_button()"
});
formatter.result({
  "duration": 936562500,
  "status": "passed"
});
formatter.match({
  "location": "SearchDeleteStep.print_the_search_result()"
});
formatter.result({
  "duration": 3183107200,
  "status": "passed"
});
formatter.scenario({
  "line": 25,
  "name": "Searching Codecharge Project in TaskMangement Website",
  "description": "",
  "id": "task-management-website;searching-codecharge-project-in-taskmangement-website",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 24,
      "name": "@TC_04_TaskList_Search"
    }
  ]
});
formatter.step({
  "line": 26,
  "name": "user launch Chrome application",
  "keyword": "Given "
});
formatter.step({
  "line": 27,
  "name": "Search as Codecharge in Project",
  "keyword": "When "
});
formatter.step({
  "line": 28,
  "name": "click on the search button get the search result",
  "keyword": "Then "
});
formatter.match({
  "location": "SearchProjectStep.the_user_launch_chrome_sepro()"
});
formatter.result({
  "duration": 11314959900,
  "status": "passed"
});
formatter.match({
  "location": "SearchProjectStep.click_dropdown_box_in_project_from_search_and_select_codecharge()"
});
formatter.result({
  "duration": 137079600,
  "status": "passed"
});
formatter.match({
  "location": "SearchProjectStep.click_on_the_search_button()"
});
formatter.result({
  "duration": 4100757000,
  "status": "passed"
});
formatter.scenario({
  "line": 31,
  "name": "Printing anyone employee name and email from employee Deatils in TaskMangement Website",
  "description": "",
  "id": "task-management-website;printing-anyone-employee-name-and-email-from-employee-deatils-in-taskmangement-website",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 30,
      "name": "@Tc_05_Employees_list_printing"
    }
  ]
});
formatter.step({
  "line": 32,
  "name": "launch Chrome application",
  "keyword": "Given "
});
formatter.step({
  "line": 33,
  "name": "Clicking Adminstration",
  "keyword": "When "
});
formatter.step({
  "line": 34,
  "name": "Click on employee details",
  "keyword": "Then "
});
formatter.step({
  "line": 35,
  "name": "Print the anyone Employee name and email in the console",
  "keyword": "And "
});
formatter.match({
  "location": "EmployeeDetailsStep.the_user_launch_chrome_em()"
});
formatter.result({
  "duration": 11292222400,
  "status": "passed"
});
formatter.match({
  "location": "EmployeeDetailsStep.clicking_Adminstration()"
});
formatter.result({
  "duration": 2295062199,
  "status": "passed"
});
formatter.match({
  "location": "EmployeeDetailsStep.click_on_employee_details()"
});
formatter.result({
  "duration": 545766800,
  "status": "passed"
});
formatter.match({
  "location": "EmployeeDetailsStep.print_the_anyone_Employees_list_in_the_console()"
});
formatter.result({
  "duration": 3204843899,
  "status": "passed"
});
});